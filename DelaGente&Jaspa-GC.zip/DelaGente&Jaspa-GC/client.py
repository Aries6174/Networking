import time
import socket
import tkinter as tk
from tkinter import scrolledtext
import threading

# Create a socket for the client
soc = socket.socket()

# GUI setup
root = tk.Tk()
root.title("Client Chat")

# Ask for custom name
name = input("Enter your name: ")

# Get the server IP address and port
server_host = input("Enter server's IP address: ")
port = 1423

# Connecting to the server
print(f"Trying to connect to the server: {server_host}, ({port})")
time.sleep(1)
soc.connect((server_host, port))
print("***Connected to the server***")

# Now that the socket is connected, retrieve the client port
client_port = soc.getsockname()[1]

# Add client name label at the top of the chat box
client_label = tk.Label(root, text=f"Client {client_port}: {name}", font=("Helvetica", 12, "bold"))
client_label.grid(row=0, column=0, padx=10, pady=(10, 0))

# Create a text area for conversation
chat_area = scrolledtext.ScrolledText(root, wrap=tk.WORD, width=50, height=20, state=tk.DISABLED)
chat_area.grid(row=1, column=0, padx=10, pady=(5, 10))

# Function to update chat
def update_chat(message):
    chat_area.config(state=tk.NORMAL)
    chat_area.insert(tk.END, message + '\n')
    chat_area.config(state=tk.DISABLED)
    chat_area.yview(tk.END)

# Send the name to the server
soc.send(name.encode())

chat_active = True

# Function to send message
def send_message():
    global chat_active
    if chat_active:
        message = input_field.get()
        try:
            soc.send(message.encode())
            if message == "[bye]":
                update_chat("You left the chat room.")
                chat_active = False
                # Schedule the window to close after 2 seconds
                root.after(2000, root.quit)
            else:
                update_chat(f"Me > {message}")
            input_field.delete(0, tk.END)
        except Exception as e:
            update_chat(f"Error sending message: {e}")

# Function to handle receiving messages
def receive_messages():
    while True:
        try:
            message = soc.recv(1024).decode()
            if "has joined" in message or "has left" in message or "Connected to the server" in message:
                update_chat(message)
            else:
                update_chat(f"{message}")
        except ConnectionResetError:
            update_chat("Disconnected from the server.")
            break

# Placeholder functions
def clear_placeholder(event):
    if input_field.get() == "Write your message here":
        input_field.delete(0, tk.END)
        input_field.config(fg="black")

def add_placeholder(event):
    if not input_field.get():
        input_field.insert(0, "Write your message here")
        input_field.config(fg="grey")

# Input field with placeholder text
input_field = tk.Entry(root, width=50, fg="grey")
input_field.grid(row=2, column=0, padx=10, pady=10)
input_field.insert(0, "Write your message here")

# Bind placeholder functions to the input field
input_field.bind("<FocusIn>", clear_placeholder)
input_field.bind("<FocusOut>", add_placeholder)

# Send button
send_button = tk.Button(root, text="Send", command=send_message)
send_button.grid(row=3, column=0, pady=10)

# Start the receiving thread
receive_thread = threading.Thread(target=receive_messages, daemon=True)
receive_thread.start()

root.mainloop()
