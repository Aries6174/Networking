import socket
import tkinter as tk
from tkinter import scrolledtext
import threading

# Set up server information
server_socket = socket.socket()
host = socket.gethostname()
ip = socket.gethostbyname(host)
port = 1423
server_socket.bind((host, port))
server_socket.listen()

print(f"Server is running on {host} with IP {ip} and port {port}")

# GUI setup
root = tk.Tk()
root.title("Server Chat")

# Add "SERVER" label at the top
server_label = tk.Label(root, text="SERVER", font=("Helvetica", 12, "bold"))
server_label.grid(row=0, column=0, padx=10, pady=(10, 0))

# Create a text area for conversation
chat_area = scrolledtext.ScrolledText(root, wrap=tk.WORD, width=50, height=20, state=tk.DISABLED)
chat_area.grid(row=1, column=0, padx=10, pady=(5, 10))

# Function to update chat in GUI
def update_chat(message):
    chat_area.config(state=tk.NORMAL)
    chat_area.insert(tk.END, message + '\n')
    chat_area.config(state=tk.DISABLED)
    chat_area.yview(tk.END)

# Display initial waiting message in the GUI
update_chat("Waiting for clients to connect...")

# List to keep track of connected clients
clients = []
client_names = {}

# Broadcast a message to all connected clients
def broadcast(message, sender_socket=None):
    for client in clients:
        if client != sender_socket:  # Skip sending to the sender
            try:
                client.send(message.encode())
            except:
                clients.remove(client)

# Function to handle a new client connection
def accept_clients():
    while True:
        client_socket, client_address = server_socket.accept()
        clients.append(client_socket)

        # Enable the send button if at least one client is connected
        send_button.config(state=tk.NORMAL)

        # Start a new thread for each client to handle messages
        threading.Thread(target=handle_client, args=(client_socket,)).start()

# Function to send a message from the server to all clients
def send_message():
    if clients:  # Check if there are connected clients
        message = input_field.get()
        if message == "[bye]":
            goodbye_message = "Server has left the chat room."
            update_chat(goodbye_message)
            broadcast(goodbye_message)
            for client in clients:
                client.close()
            root.quit()
        else:
            formatted_message = f"Server > {message}"
            update_chat(formatted_message)
            broadcast(formatted_message)
        input_field.delete(0, tk.END)

# Function to handle messages from a client
def handle_client(client_socket):
    try:
        # Receive client name
        client_name = client_socket.recv(1024).decode()
        client_names[client_socket] = client_name
        welcome_message = f"{client_name} has joined the chat room."
        
        # Display the join message in server's GUI only
        update_chat(welcome_message)

        # Send immediate confirmation to the new client
        client_socket.send("***You are now connected to the chat room!***".encode())

        # Main loop to receive messages from this client
        while True:
            
            message = client_socket.recv(1024).decode()
            if message == "[bye]":
                leave_message = f"{client_name} has left the chat room."
                
                # Display leave message in server GUI only
                update_chat(leave_message)
                
                clients.remove(client_socket)
                client_socket.close()
                break
            else:
                # Show the client's message with arrow format
                formatted_message = f"{client_name} > {message}"
                update_chat(formatted_message)
                broadcast(formatted_message, client_socket)
    except ConnectionResetError:
        if client_socket in clients:
            clients.remove(client_socket)
        disconnected_message = f"{client_names[client_socket]} has disconnected unexpectedly."
        update_chat(disconnected_message)
    finally:
        # Disable the send button if no clients are connected
        if not clients:
            send_button.config(state=tk.DISABLED)

# Placeholder functions for the input field
def clear_placeholder(event):
    if input_field.get() == "Type your message here":
        input_field.delete(0, tk.END)
        input_field.config(fg="black")

def add_placeholder(event):
    if not input_field.get():
        input_field.insert(0, "Type your message here")
        input_field.config(fg="grey")

# Input field for typing messages with placeholder text
input_field = tk.Entry(root, width=50, fg="grey")
input_field.grid(row=2, column=0, padx=10, pady=10)
input_field.insert(0, "Type your message here")

# Bind placeholder functions to the input field
input_field.bind("<FocusIn>", clear_placeholder)
input_field.bind("<FocusOut>", add_placeholder)

# Send button, initially disabled
send_button = tk.Button(root, text="Send", command=send_message, state=tk.DISABLED)
send_button.grid(row=3, column=0, pady=10)

# Start the accepting clients thread
threading.Thread(target=accept_clients, daemon=True).start()

root.mainloop()
